import { getStoreRuntimeEnv } from "../lib/runtime-env";

const SCHEMA_VERSION = "1";

const schemaStatements = [
  `CREATE TABLE IF NOT EXISTS admin_login_attempts (
    key TEXT PRIMARY KEY NOT NULL,
    attempts INTEGER DEFAULT 0 NOT NULL,
    window_started INTEGER NOT NULL,
    blocked_until INTEGER DEFAULT 0 NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS admins (
    username TEXT PRIMARY KEY NOT NULL,
    display_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    password_salt TEXT NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY NOT NULL,
    customer_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    city TEXT DEFAULT '' NOT NULL,
    notes TEXT DEFAULT '' NOT NULL,
    items_json TEXT NOT NULL,
    total_halalas INTEGER NOT NULL,
    status TEXT DEFAULT 'new' NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
    name TEXT NOT NULL,
    description TEXT DEFAULT '' NOT NULL,
    category TEXT DEFAULT 'منتجات النادي' NOT NULL,
    price_halalas INTEGER NOT NULL,
    stock INTEGER DEFAULT 0 NOT NULL,
    is_available INTEGER DEFAULT true NOT NULL,
    is_featured INTEGER DEFAULT false NOT NULL,
    image_key TEXT,
    sizes_json TEXT DEFAULT '[]' NOT NULL,
    created_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
  )`,
  `CREATE TABLE IF NOT EXISTS store_meta (
    key TEXT PRIMARY KEY NOT NULL,
    value TEXT NOT NULL,
    updated_at TEXT DEFAULT CURRENT_TIMESTAMP NOT NULL
  )`,
] as const;

/**
 * Dashboard and automatic-provisioning deployments may create a fresh D1
 * database without running the CLI migration command. Keep startup idempotent
 * so the first API request can safely prepare that database.
 */
export async function ensureStoreSchema() {
  const { DB } = getStoreRuntimeEnv();
  const existingVersion = await DB.prepare(
    "SELECT value FROM store_meta WHERE key = 'schema_version' LIMIT 1",
  )
    .first<{ value: string }>()
    .catch(() => null);

  if (existingVersion?.value === SCHEMA_VERSION) return;

  const statements = schemaStatements.map((statement) => DB.prepare(statement));
  statements.push(
    DB.prepare(
      `INSERT INTO store_meta (key, value, updated_at)
       VALUES ('schema_version', ?, CURRENT_TIMESTAMP)
       ON CONFLICT(key) DO UPDATE SET
         value = excluded.value,
         updated_at = CURRENT_TIMESTAMP`,
    ).bind(SCHEMA_VERSION),
  );
  await DB.batch(statements);
}
