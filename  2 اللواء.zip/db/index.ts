import { drizzle } from "drizzle-orm/d1";
import { getStoreRuntimeEnv } from "../lib/runtime-env";
import * as schema from "./schema";
import { ensureStoreSchema } from "./bootstrap";

export function getDb() {
  const env = getStoreRuntimeEnv();
  if (!env.DB) {
    throw new Error(
      "Cloudflare D1 binding `DB` is unavailable. Check wrangler.jsonc before using the database."
    );
  }

  return drizzle(env.DB, { schema });
}

export async function getReadyDb() {
  await ensureStoreSchema();
  return getDb();
}
