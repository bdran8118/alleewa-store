import { listProducts } from "../../../lib/store-db";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const products = await listProducts(false);
    return Response.json({ products });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر تحميل المنتجات";
    return Response.json({ error: message }, { status: 500 });
  }
}
