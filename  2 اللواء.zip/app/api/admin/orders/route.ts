import { requireAdmin } from "../../../../lib/admin-auth";
import { listOrders } from "../../../../lib/store-db";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;
  return Response.json({ orders: await listOrders() });
}
