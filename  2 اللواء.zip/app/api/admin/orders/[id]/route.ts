import { eq, sql } from "drizzle-orm";
import { getReadyDb } from "../../../../../db";
import { orders } from "../../../../../db/schema";
import { requireAdmin } from "../../../../../lib/admin-auth";

const statuses = new Set(["new", "processing", "ready", "completed", "cancelled"]);

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;
  const { id } = await context.params;
  const payload = (await request.json()) as { status?: string };
  const status = String(payload.status ?? "");
  if (!statuses.has(status)) {
    return Response.json({ error: "حالة الطلب غير صحيحة" }, { status: 400 });
  }

  const [updated] = await (await getReadyDb())
    .update(orders)
    .set({ status, updatedAt: sql`CURRENT_TIMESTAMP` })
    .where(eq(orders.id, id))
    .returning();
  if (!updated) return Response.json({ error: "الطلب غير موجود" }, { status: 404 });
  return Response.json({ success: true });
}
