import { getReadyDb } from "../../../../db";
import { admins } from "../../../../db/schema";
import {
  adminUsername,
  clearLoginFailures,
  createAdminSessionCookie,
  createPasswordRecord,
  getConfiguredAdmin,
  getLoginRateLimit,
  matchesAdminSetupCode,
  recordLoginFailure,
  rejectCrossOrigin,
} from "../../../../lib/admin-auth";

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  try {
    const rateLimit = await getLoginRateLimit(request);
    if (!rateLimit.allowed) {
      return Response.json(
        { error: "محاولات كثيرة. حاول بعد قليل" },
        {
          status: 429,
          headers: { "retry-after": String(rateLimit.retryAfter) },
        },
      );
    }

    if (await getConfiguredAdmin()) {
      return Response.json(
        { error: "تم إعداد مدير المتجر مسبقًا" },
        { status: 409 },
      );
    }

    const payload = (await request.json()) as {
      setupCode?: string;
      displayName?: string;
      password?: string;
    };
    const setupCode = String(payload.setupCode ?? "").trim();
    if (!(await matchesAdminSetupCode(setupCode))) {
      await recordLoginFailure(rateLimit.key);
      return Response.json(
        { error: "رمز التفعيل غير صحيح" },
        { status: 401 },
      );
    }

    const displayName =
      String(payload.displayName ?? "").trim().slice(0, 60) || "مدير المتجر";
    const password = String(payload.password ?? "");
    const passwordRecord = await createPasswordRecord(password);
    const user = { username: adminUsername(), displayName };

    await (await getReadyDb()).insert(admins).values({
      ...user,
      ...passwordRecord,
    });
    await clearLoginFailures(rateLimit.key);

    return Response.json(
      { success: true, user },
      {
        status: 201,
        headers: { "set-cookie": await createAdminSessionCookie(user) },
      },
    );
  } catch (error) {
    const rawMessage =
      error instanceof Error ? error.message : "تعذر إعداد حساب الإدارة";
    console.error("Admin setup failed", error);
    const message = rawMessage.includes("SESSION_SECRET")
      ? "إعداد SESSION_SECRET في Cloudflare مفقود أو أقصر من 32 حرفًا"
      : rawMessage.includes("ADMIN_SETUP_CODE")
        ? "إعداد ADMIN_SETUP_CODE في Cloudflare مفقود"
        : rawMessage;
    const status = rawMessage.includes("UNIQUE")
      ? 409
      : rawMessage.includes("SESSION_SECRET") ||
          rawMessage.includes("ADMIN_SETUP_CODE")
        ? 500
        : 400;
    return Response.json({ error: message }, { status });
  }
}
