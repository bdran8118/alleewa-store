import { getAdminState } from "../../../../lib/admin-auth";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const state = await getAdminState(request);
    return Response.json({
      signedIn: Boolean(state.user),
      isAdmin: state.isAdmin,
      canSetup: state.canSetup,
      user: state.user
        ? {
            username: state.user.username,
            displayName: state.user.displayName,
          }
        : null,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر التحقق من الصلاحية";
    return Response.json({ error: message }, { status: 500 });
  }
}
