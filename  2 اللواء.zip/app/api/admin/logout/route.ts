import {
  clearAdminSessionCookie,
  rejectCrossOrigin,
} from "../../../../lib/admin-auth";

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  return new Response(null, {
    status: 303,
    headers: {
      location: new URL("/admin", request.url).toString(),
      "set-cookie": clearAdminSessionCookie(),
    },
  });
}
