import { requireAdmin } from "../../../../lib/admin-auth";
import { getStoreRuntimeEnv } from "../../../../lib/runtime-env";

const allowedTypes = new Map([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["image/avif", "avif"],
]);

export async function POST(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;

  const formData = await request.formData();
  const file = formData.get("file");
  if (!(file instanceof File)) {
    return Response.json({ error: "اختر صورة للمنتج" }, { status: 400 });
  }
  const extension = allowedTypes.get(file.type);
  if (!extension) {
    return Response.json({ error: "الصيغة المدعومة: JPG أو PNG أو WEBP أو AVIF" }, { status: 400 });
  }
  if (file.size > 8 * 1024 * 1024) {
    return Response.json({ error: "حجم الصورة يجب ألا يتجاوز 8 ميجابايت" }, { status: 400 });
  }

  const key = "products/" + crypto.randomUUID() + "." + extension;
  const body = await file.arrayBuffer();
  const checksum = await crypto.subtle.digest("SHA-256", body);
  const etag = [...new Uint8Array(checksum)]
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
  await getStoreRuntimeEnv().IMAGES_KV.put(key, body, {
    metadata: {
      contentType: file.type,
      etag,
      uploadedBy: admin.user.username,
    },
  });
  const imageUrl = `/api/images/${key.split("/").map(encodeURIComponent).join("/")}`;
  return Response.json({ imageKey: key, imageUrl });
}
