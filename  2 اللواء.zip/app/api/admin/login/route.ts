import {
  clearLoginFailures,
  createAdminSessionCookie,
  getConfiguredAdmin,
  getLoginRateLimit,
  recordLoginFailure,
  rejectCrossOrigin,
  verifyAdminPassword,
} from "../../../../lib/admin-auth";

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  try {
    const rateLimit = await getLoginRateLimit(request);
    if (!rateLimit.allowed) {
      return Response.json(
        { error: "محاولات كثيرة. حاول بعد قليل" },
        {
          status: 429,
          headers: { "retry-after": String(rateLimit.retryAfter) },
        },
      );
    }

    const payload = (await request.json()) as { password?: string };
    const password = String(payload.password ?? "");
    const admin = await getConfiguredAdmin();
    const valid =
      admin &&
      (await verifyAdminPassword(
        password,
        admin.passwordSalt,
        admin.passwordHash,
      ));

    if (!admin || !valid) {
      await recordLoginFailure(rateLimit.key);
      return Response.json(
        { error: "كلمة المرور غير صحيحة" },
        { status: 401 },
      );
    }

    await clearLoginFailures(rateLimit.key);
    const user = {
      username: admin.username,
      displayName: admin.displayName,
    };
    return Response.json(
      { success: true, user },
      { headers: { "set-cookie": await createAdminSessionCookie(user) } },
    );
  } catch (error) {
    console.error("Admin login failed", error);
    const rawMessage =
      error instanceof Error ? error.message : "تعذر تسجيل الدخول";
    const message = rawMessage.includes("SESSION_SECRET")
      ? "إعداد SESSION_SECRET في Cloudflare مفقود أو أقصر من 32 حرفًا"
      : "تعذر تسجيل الدخول";
    return Response.json(
      { error: message },
      { status: rawMessage.includes("SESSION_SECRET") ? 500 : 400 },
    );
  }
}
