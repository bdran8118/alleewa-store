import { getReadyDb } from "../../../../db";
import { products } from "../../../../db/schema";
import { requireAdmin } from "../../../../lib/admin-auth";
import {
  listProducts,
  normalizeProductInput,
  productToPublic,
} from "../../../../lib/store-db";
import type { ProductInput } from "../../../../lib/store-types";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;
  return Response.json({ products: await listProducts(true) });
}

export async function POST(request: Request) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;

  try {
    const payload = (await request.json()) as Partial<ProductInput>;
    const values = normalizeProductInput(payload);
    const [created] = await (await getReadyDb())
      .insert(products)
      .values(values)
      .returning();
    return Response.json({ product: productToPublic(created) }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر إضافة المنتج";
    return Response.json({ error: message }, { status: 400 });
  }
}
