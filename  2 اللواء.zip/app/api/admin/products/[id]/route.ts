import { eq, sql } from "drizzle-orm";
import { getReadyDb } from "../../../../../db";
import { products } from "../../../../../db/schema";
import { requireAdmin } from "../../../../../lib/admin-auth";
import { getStoreRuntimeEnv } from "../../../../../lib/runtime-env";
import { normalizeProductInput, productToPublic } from "../../../../../lib/store-db";
import type { ProductInput } from "../../../../../lib/store-types";

async function getId(context: { params: Promise<{ id: string }> }) {
  const { id } = await context.params;
  const productId = Number(id);
  return Number.isInteger(productId) && productId > 0 ? productId : null;
}

export async function PATCH(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;
  const id = await getId(context);
  if (!id) return Response.json({ error: "رقم المنتج غير صحيح" }, { status: 400 });

  const db = await getReadyDb();
  const [existing] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!existing) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });

  try {
    const payload = (await request.json()) as Partial<ProductInput>;
    const currentSizes = JSON.parse(existing.sizesJson) as string[];
    const values = normalizeProductInput({
      name: existing.name,
      description: existing.description,
      category: existing.category,
      priceHalalas: existing.priceHalalas,
      stock: existing.stock,
      isAvailable: existing.isAvailable,
      isFeatured: existing.isFeatured,
      imageKey: existing.imageKey,
      sizes: currentSizes,
      ...payload,
    });

    const [updated] = await db
      .update(products)
      .set({ ...values, updatedAt: sql`CURRENT_TIMESTAMP` })
      .where(eq(products.id, id))
      .returning();

    if (existing.imageKey && existing.imageKey !== values.imageKey) {
      await getStoreRuntimeEnv().IMAGES_KV.delete(existing.imageKey);
    }
    return Response.json({ product: productToPublic(updated) });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر تحديث المنتج";
    return Response.json({ error: message }, { status: 400 });
  }
}

export async function DELETE(
  request: Request,
  context: { params: Promise<{ id: string }> },
) {
  const admin = await requireAdmin(request);
  if (!admin.ok) return admin.response;
  const id = await getId(context);
  if (!id) return Response.json({ error: "رقم المنتج غير صحيح" }, { status: 400 });

  const db = await getReadyDb();
  const [existing] = await db.select().from(products).where(eq(products.id, id)).limit(1);
  if (!existing) return Response.json({ error: "المنتج غير موجود" }, { status: 404 });

  await db.delete(products).where(eq(products.id, id));
  if (existing.imageKey) {
    await getStoreRuntimeEnv().IMAGES_KV.delete(existing.imageKey);
  }
  return Response.json({ success: true });
}
