import { getStoreRuntimeEnv } from "../../../../lib/runtime-env";

export const dynamic = "force-dynamic";

type ImageMetadata = {
  contentType?: string;
  etag?: string;
};

export async function GET(
  _request: Request,
  context: { params: Promise<{ key: string[] }> },
) {
  const { key: segments } = await context.params;
  const key = segments.map(decodeURIComponent).join("/");
  if (
    !/^products\/[0-9a-f-]+\.(?:jpg|png|webp|avif)$/u.test(key) ||
    key.includes("..")
  ) {
    return new Response("Not found", { status: 404 });
  }

  const object = await getStoreRuntimeEnv().IMAGES_KV.getWithMetadata<ImageMetadata>(
    key,
    "stream",
  );
  if (!object.value) return new Response("Not found", { status: 404 });

  const headers = new Headers();
  headers.set(
    "content-type",
    object.metadata?.contentType ?? "application/octet-stream",
  );
  if (object.metadata?.etag) {
    headers.set("etag", '"' + object.metadata.etag + '"');
  }
  headers.set("cache-control", "public, max-age=31536000, immutable");
  return new Response(object.value, { headers });
}
