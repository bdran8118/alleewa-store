import { inArray, sql } from "drizzle-orm";
import { getReadyDb } from "../../../db";
import { orders, products } from "../../../db/schema";
import { rejectCrossOrigin } from "../../../lib/admin-auth";

type OrderRequest = {
  customerName?: string;
  phone?: string;
  city?: string;
  notes?: string;
  items?: Array<{ productId?: number; quantity?: number; selectedSize?: string }>;
};

function cleanPhone(value: string) {
  return value.replace(/[^0-9+]/g, "");
}

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  try {
    const payload = (await request.json()) as OrderRequest;
    const customerName = String(payload.customerName ?? "").trim();
    const phone = cleanPhone(String(payload.phone ?? ""));
    const city = String(payload.city ?? "").trim();
    const notes = String(payload.notes ?? "").trim().slice(0, 500);
    const submittedItems = Array.isArray(payload.items) ? payload.items : [];

    if (customerName.length < 2) {
      return Response.json({ error: "اكتب اسم المستلم" }, { status: 400 });
    }
    if (!/^(?:\+?966|0)?5\d{8}$/.test(phone)) {
      return Response.json({ error: "رقم الجوال غير صحيح" }, { status: 400 });
    }
    if (!submittedItems.length) {
      return Response.json({ error: "السلة فارغة" }, { status: 400 });
    }

    const quantities = new Map<number, { quantity: number; selectedSize: string }>();
    for (const item of submittedItems) {
      const productId = Number(item.productId);
      const quantity = Math.max(1, Math.min(20, Math.floor(Number(item.quantity))));
      if (!Number.isInteger(productId) || productId < 1) continue;
      const previous = quantities.get(productId)?.quantity ?? 0;
      quantities.set(productId, {
        quantity: Math.min(20, previous + quantity),
        selectedSize: String(item.selectedSize ?? "").trim().slice(0, 30),
      });
    }

    const productIds = [...quantities.keys()];
    if (!productIds.length) {
      return Response.json({ error: "السلة غير صالحة" }, { status: 400 });
    }

    const db = await getReadyDb();
    const availableProducts = await db
      .select()
      .from(products)
      .where(inArray(products.id, productIds));

    if (availableProducts.length !== productIds.length) {
      return Response.json({ error: "أحد المنتجات لم يعد موجودًا" }, { status: 409 });
    }

    const orderItems = availableProducts.map((product) => {
      const selection = quantities.get(product.id)!;
      if (!product.isAvailable || product.stock < selection.quantity) {
        throw new Error(`الكمية المطلوبة من ${product.name} غير متوفرة`);
      }
      const sizes = JSON.parse(product.sizesJson) as string[];
      if (sizes.length && !sizes.includes(selection.selectedSize)) {
        throw new Error(`اختر مقاسًا صحيحًا للمنتج ${product.name}`);
      }
      return {
        productId: product.id,
        name: product.name,
        priceHalalas: product.priceHalalas,
        quantity: selection.quantity,
        selectedSize: selection.selectedSize,
      };
    });

    const totalHalalas = orderItems.reduce(
      (total, item) => total + item.priceHalalas * item.quantity,
      0,
    );
    const id = `LW-${Date.now().toString(36).toUpperCase()}-${crypto
      .randomUUID()
      .slice(0, 4)
      .toUpperCase()}`;

    await db.insert(orders).values({
      id,
      customerName,
      phone,
      city,
      notes,
      itemsJson: JSON.stringify(orderItems),
      totalHalalas,
    });

    for (const item of orderItems) {
      await db
        .update(products)
        .set({
          stock: sql`${products.stock} - ${item.quantity}`,
          updatedAt: sql`CURRENT_TIMESTAMP`,
        })
        .where(inArray(products.id, [item.productId]));
    }

    return Response.json({ orderId: id, totalHalalas }, { status: 201 });
  } catch (error) {
    const message = error instanceof Error ? error.message : "تعذر إرسال الطلب";
    const status = message.includes("غير متوفرة") || message.includes("مقاس") ? 409 : 500;
    return Response.json({ error: message }, { status });
  }
}
