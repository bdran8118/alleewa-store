"use client";

import { useEffect, useMemo, useState } from "react";
import type { CartItem, StoreProduct } from "../lib/store-types";

const money = new Intl.NumberFormat("ar-SA", {
  style: "currency",
  currency: "SAR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

function formatMoney(halalas: number) {
  return money.format(halalas / 100);
}

function cartKey(item: Pick<CartItem, "product" | "selectedSize">) {
  return `${item.product.id}:${item.selectedSize}`;
}

export default function Storefront() {
  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("الكل");
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<StoreProduct | null>(null);
  const [selectedSize, setSelectedSize] = useState("");
  const [cartReady, setCartReady] = useState(false);
  const [toast, setToast] = useState("");

  useEffect(() => {
    void loadProducts();
  }, []);

  useEffect(() => {
    if (!cartReady) return;
    localStorage.setItem("alleewa-store-cart", JSON.stringify(cart));
  }, [cart, cartReady]);

  useEffect(() => {
    document.body.style.overflow = cartOpen || selectedProduct ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [cartOpen, selectedProduct]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2400);
    return () => window.clearTimeout(timer);
  }, [toast]);

  async function loadProducts() {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/products", { cache: "no-store" });
      const data = (await response.json()) as { products?: StoreProduct[]; error?: string };
      if (!response.ok) throw new Error(data.error || "تعذر تحميل المنتجات");
      const nextProducts = data.products ?? [];
      setProducts(nextProducts);

      const rawCart = localStorage.getItem("alleewa-store-cart");
      if (rawCart) {
        try {
          const saved = JSON.parse(rawCart) as CartItem[];
          const hydrated = saved
            .map((item) => {
              const latest = nextProducts.find((product) => product.id === item.product.id);
              if (!latest) return null;
              return {
                product: latest,
                quantity: Math.min(item.quantity, latest.stock),
                selectedSize: item.selectedSize,
              };
            })
            .filter((item): item is CartItem => Boolean(item && item.quantity > 0));
          setCart(hydrated);
        } catch {
          localStorage.removeItem("alleewa-store-cart");
        }
      }
      setCartReady(true);
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "تعذر تحميل المنتجات");
    } finally {
      setLoading(false);
    }
  }

  const categories = useMemo(
    () => ["الكل", ...new Set(products.map((product) => product.category).filter(Boolean))],
    [products],
  );

  const visibleProducts = useMemo(() => {
    const term = search.trim().toLowerCase();
    return products.filter((product) => {
      const matchesCategory = category === "الكل" || product.category === category;
      const matchesSearch =
        !term ||
        product.name.toLowerCase().includes(term) ||
        product.description.toLowerCase().includes(term);
      return matchesCategory && matchesSearch;
    });
  }, [products, search, category]);

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  function openProduct(product: StoreProduct) {
    setSelectedProduct(product);
    setSelectedSize(product.sizes[0] ?? "");
  }

  function addToCart(product: StoreProduct, size = "") {
    if (!product.isAvailable || product.stock < 1) return;
    if (product.sizes.length && !size) {
      openProduct(product);
      return;
    }
    setCart((current) => {
      const key = `${product.id}:${size}`;
      const existing = current.find((item) => cartKey(item) === key);
      if (existing) {
        return current.map((item) =>
          cartKey(item) === key
            ? { ...item, quantity: Math.min(item.quantity + 1, product.stock) }
            : item,
        );
      }
      return [...current, { product, quantity: 1, selectedSize: size }];
    });
    setSelectedProduct(null);
    setToast("تمت إضافة المنتج إلى السلة");
  }

  function updateQuantity(item: CartItem, delta: number) {
    const key = cartKey(item);
    setCart((current) =>
      current
        .map((entry) =>
          cartKey(entry) === key
            ? {
                ...entry,
                quantity: Math.max(0, Math.min(entry.quantity + delta, entry.product.stock)),
              }
            : entry,
        )
        .filter((entry) => entry.quantity > 0),
    );
  }

  function removeCartItem(item: CartItem) {
    const key = cartKey(item);
    setCart((current) => current.filter((entry) => cartKey(entry) !== key));
  }

  return (
    <main className="store-shell">
      <header className="store-header">
        <div className="header-inner">
          <a className="brand" href="#top" aria-label="متجر نادي اللواء">
            <img src="/club-logo.jpeg" alt="شعار نادي اللواء" />
            <span>
              <strong>متجر نادي اللواء</strong>
              <small>AL LEEWA CLUB STORE</small>
            </span>
          </a>
          <nav className="desktop-nav" aria-label="التنقل الرئيسي">
            <a href="#products">المنتجات</a>
            <a href="#about">عن المتجر</a>
          </nav>
          <button className="cart-button" type="button" onClick={() => setCartOpen(true)}>
            <span className="cart-glyph" aria-hidden="true">⌑</span>
            <span>السلة</span>
            <b>{cartCount}</b>
          </button>
        </div>
      </header>

      <section className="hero" id="top">
        <img className="hero-banner" src="/club-banner.jpeg" alt="هوية نادي اللواء" />
        <div className="hero-overlay" />
        <div className="hero-content">
          <div className="hero-copy">
            <span className="eyebrow"><i /> أهل الصفاة</span>
            <h1>ألوان اللواء<br /><em>تليق بك</em></h1>
            <p>تصفّح منتجات النادي، اختر الكمية والمقاس، وأرسل طلبك بخطوات واضحة وسريعة.</p>
            <div className="hero-actions">
              <a className="primary-cta" href="#products">تصفّح المنتجات <span>←</span></a>
              <button className="secondary-cta" type="button" onClick={() => setCartOpen(true)}>
                عرض السلة ({cartCount})
              </button>
            </div>
          </div>
          <div className="hero-crest" aria-hidden="true">
            <div className="crest-ring"><img src="/club-logo.jpeg" alt="" /></div>
            <span>منذ 1976</span>
          </div>
        </div>
        <div className="hero-stripe" />
      </section>

      <section className="service-strip" id="about" aria-label="مزايا المتجر">
        <div><span>01</span><p><strong>مخزون واضح</strong><small>الكمية وحالة التوفر أمامك</small></p></div>
        <div><span>02</span><p><strong>طلب سريع</strong><small>سلة موحدة ورقم طلب مباشر</small></p></div>
        <div><span>03</span><p><strong>منتجات النادي</strong><small>كل المنتجات في مكان واحد</small></p></div>
      </section>

      <section className="products-section" id="products">
        <div className="section-heading">
          <div>
            <span className="section-kicker">متجر أهل الصفاة</span>
            <h2>منتجات النادي</h2>
          </div>
          <label className="search-box">
            <span aria-hidden="true">⌕</span>
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              placeholder="ابحث عن منتج"
              aria-label="البحث في المنتجات"
            />
          </label>
        </div>

        {categories.length > 1 && (
          <div className="category-tabs" role="tablist" aria-label="تصنيفات المنتجات">
            {categories.map((item) => (
              <button
                key={item}
                className={category === item ? "active" : ""}
                type="button"
                onClick={() => setCategory(item)}
              >
                {item}
              </button>
            ))}
          </div>
        )}

        {loading ? (
          <div className="product-grid" aria-label="جاري تحميل المنتجات">
            {[0, 1, 2, 3].map((item) => <div className="product-skeleton" key={item} />)}
          </div>
        ) : error ? (
          <div className="state-card error-state">
            <span>!</span><h3>تعذر عرض المنتجات</h3><p>{error}</p>
            <button type="button" onClick={() => void loadProducts()}>إعادة المحاولة</button>
          </div>
        ) : visibleProducts.length ? (
          <div className="product-grid">
            {visibleProducts.map((product) => {
              const unavailable = !product.isAvailable || product.stock < 1;
              return (
                <article className={`product-card ${unavailable ? "unavailable" : ""}`} key={product.id}>
                  <button className="product-image" type="button" onClick={() => openProduct(product)}>
                    {product.imageUrl ? (
                      <img src={product.imageUrl} alt={product.name} />
                    ) : (
                      <span className="image-placeholder"><img src="/club-logo.jpeg" alt="" /></span>
                    )}
                    {product.isFeatured && !unavailable && <b className="featured-badge">مختار</b>}
                    {unavailable && <b className="sold-badge">غير متوفر</b>}
                  </button>
                  <div className="product-body">
                    <span className="product-category">{product.category}</span>
                    <button className="product-title" type="button" onClick={() => openProduct(product)}>
                      {product.name}
                    </button>
                    <p>{product.description || "تفاصيل المنتج متاحة عند الاختيار."}</p>
                    <div className="product-meta">
                      <div><strong>{formatMoney(product.priceHalalas)}</strong><small>{product.stock > 0 ? `متبقي ${product.stock}` : "نفد المخزون"}</small></div>
                      <button
                        className="add-button"
                        type="button"
                        disabled={unavailable}
                        onClick={() => product.sizes.length ? openProduct(product) : addToCart(product)}
                        aria-label={`إضافة ${product.name} إلى السلة`}
                      >
                        <span>+</span>
                      </button>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        ) : products.length ? (
          <div className="state-card"><span>⌕</span><h3>لا توجد نتائج</h3><p>جرّب كلمة بحث أو تصنيفًا آخر.</p></div>
        ) : (
          <div className="state-card empty-store">
            <img src="/club-logo.jpeg" alt="شعار نادي اللواء" />
            <h3>المنتجات ستظهر هنا</h3>
            <p>يمكن لمدير المتجر إضافة المنتجات والصور والأسعار والكميات من لوحة الإدارة.</p>
          </div>
        )}
      </section>

      <footer className="store-footer">
        <div className="footer-brand">
          <img src="/club-logo.jpeg" alt="شعار نادي اللواء" />
          <div><strong>متجر نادي اللواء</strong><small>AL LEEWA CLUB STORE</small></div>
        </div>
        <p>منتجات النادي في واجهة واحدة سهلة وسريعة.</p>
        <a href="/admin">إدارة المتجر</a>
      </footer>

      {selectedProduct && (
        <div className="modal-layer" role="dialog" aria-modal="true" aria-label={selectedProduct.name}>
          <button className="modal-backdrop" onClick={() => setSelectedProduct(null)} aria-label="إغلاق" />
          <article className="product-modal">
            <button className="close-button" type="button" onClick={() => setSelectedProduct(null)} aria-label="إغلاق">×</button>
            <div className="modal-product-image">
              {selectedProduct.imageUrl ? <img src={selectedProduct.imageUrl} alt={selectedProduct.name} /> : <img className="modal-placeholder" src="/club-logo.jpeg" alt="" />}
            </div>
            <div className="modal-product-info">
              <span className="product-category">{selectedProduct.category}</span>
              <h2>{selectedProduct.name}</h2>
              <p>{selectedProduct.description || "لا يوجد وصف إضافي لهذا المنتج."}</p>
              <strong className="modal-price">{formatMoney(selectedProduct.priceHalalas)}</strong>
              {selectedProduct.sizes.length > 0 && (
                <div className="size-picker">
                  <label>اختر المقاس</label>
                  <div>
                    {selectedProduct.sizes.map((size) => (
                      <button key={size} type="button" className={selectedSize === size ? "active" : ""} onClick={() => setSelectedSize(size)}>{size}</button>
                    ))}
                  </div>
                </div>
              )}
              <button
                className="modal-add"
                type="button"
                disabled={!selectedProduct.isAvailable || selectedProduct.stock < 1 || (selectedProduct.sizes.length > 0 && !selectedSize)}
                onClick={() => addToCart(selectedProduct, selectedSize)}
              >
                {!selectedProduct.isAvailable || selectedProduct.stock < 1 ? "غير متوفر حاليًا" : "أضف إلى السلة"}
              </button>
              <small className="stock-note">{selectedProduct.stock > 0 ? `الكمية المتاحة: ${selectedProduct.stock}` : "نفد المخزون"}</small>
            </div>
          </article>
        </div>
      )}

      <CartDrawer
        open={cartOpen}
        cart={cart}
        onClose={() => setCartOpen(false)}
        onUpdate={updateQuantity}
        onRemove={removeCartItem}
        onOrderComplete={() => {
          setCart([]);
          void loadProducts();
        }}
      />

      {toast && <div className="toast" role="status">✓ {toast}</div>}
    </main>
  );
}

function CartDrawer({
  open,
  cart,
  onClose,
  onUpdate,
  onRemove,
  onOrderComplete,
}: {
  open: boolean;
  cart: CartItem[];
  onClose: () => void;
  onUpdate: (item: CartItem, delta: number) => void;
  onRemove: (item: CartItem) => void;
  onOrderComplete: () => void;
}) {
  const [checkout, setCheckout] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState("");
  const [orderId, setOrderId] = useState("");
  const total = cart.reduce((sum, item) => sum + item.product.priceHalalas * item.quantity, 0);

  async function submitOrder(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSubmitting(true);
    setFormError("");
    const form = new FormData(event.currentTarget);
    try {
      const response = await fetch("/api/orders", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          customerName: form.get("customerName"),
          phone: form.get("phone"),
          city: form.get("city"),
          notes: form.get("notes"),
          items: cart.map((item) => ({
            productId: item.product.id,
            quantity: item.quantity,
            selectedSize: item.selectedSize,
          })),
        }),
      });
      const data = (await response.json()) as { orderId?: string; error?: string };
      if (!response.ok || !data.orderId) throw new Error(data.error || "تعذر إرسال الطلب");
      setOrderId(data.orderId);
      onOrderComplete();
      setCheckout(false);
    } catch (error) {
      setFormError(error instanceof Error ? error.message : "تعذر إرسال الطلب");
    } finally {
      setSubmitting(false);
    }
  }

  function closeDrawer() {
    setOrderId("");
    setCheckout(false);
    setFormError("");
    onClose();
  }

  return (
    <div className={`drawer-layer ${open ? "open" : ""}`} aria-hidden={!open}>
      <button className="drawer-backdrop" type="button" onClick={closeDrawer} aria-label="إغلاق السلة" />
      <aside className="cart-drawer" role="dialog" aria-modal="true" aria-label="سلة المشتريات">
        <header>
          <div><span>{checkout ? "إكمال الطلب" : "سلة المشتريات"}</span><small>{cart.length ? `${cart.length} منتجات` : "السلة فارغة"}</small></div>
          <button type="button" onClick={closeDrawer} aria-label="إغلاق">×</button>
        </header>

        {orderId ? (
          <div className="order-success">
            <div>✓</div><h3>تم استلام طلبك</h3><p>احتفظ برقم الطلب لمتابعته مع النادي.</p>
            <strong>{orderId}</strong>
            <button type="button" onClick={closeDrawer}>العودة للمتجر</button>
          </div>
        ) : checkout ? (
          <form className="checkout-form" onSubmit={submitOrder}>
            <button className="back-cart" type="button" onClick={() => setCheckout(false)}>→ العودة إلى السلة</button>
            <label><span>اسم المستلم *</span><input name="customerName" required minLength={2} placeholder="الاسم الكامل" /></label>
            <label><span>رقم الجوال *</span><input name="phone" required inputMode="tel" dir="ltr" placeholder="05xxxxxxxx" /></label>
            <label><span>المدينة</span><input name="city" placeholder="مثال: بقعاء" /></label>
            <label><span>ملاحظات الطلب</span><textarea name="notes" rows={3} maxLength={500} placeholder="أي تفاصيل إضافية" /></label>
            {formError && <p className="form-error">{formError}</p>}
            <div className="checkout-total"><span>إجمالي الطلب</span><strong>{formatMoney(total)}</strong></div>
            <button className="checkout-submit" disabled={submitting} type="submit">{submitting ? "جاري إرسال الطلب..." : "تأكيد وإرسال الطلب"}</button>
            <small className="checkout-note">إرسال الطلب لا يتضمن دفعًا إلكترونيًا.</small>
          </form>
        ) : cart.length ? (
          <>
            <div className="cart-items">
              {cart.map((item) => (
                <article className="cart-item" key={cartKey(item)}>
                  <div className="cart-thumb">{item.product.imageUrl ? <img src={item.product.imageUrl} alt="" /> : <img src="/club-logo.jpeg" alt="" />}</div>
                  <div className="cart-details">
                    <strong>{item.product.name}</strong>
                    {item.selectedSize && <small>المقاس: {item.selectedSize}</small>}
                    <span>{formatMoney(item.product.priceHalalas)}</span>
                    <div className="quantity-control">
                      <button type="button" onClick={() => onUpdate(item, 1)}>+</button><b>{item.quantity}</b><button type="button" onClick={() => onUpdate(item, -1)}>−</button>
                    </div>
                  </div>
                  <button className="remove-item" type="button" onClick={() => onRemove(item)} aria-label={`حذف ${item.product.name}`}>×</button>
                </article>
              ))}
            </div>
            <div className="cart-summary">
              <div><span>الإجمالي</span><strong>{formatMoney(total)}</strong></div>
              <button type="button" onClick={() => { setFormError(""); setCheckout(true); }}>متابعة وإكمال الطلب</button>
              <small>السعر النهائي قبل أي تكاليف تسليم يتم الاتفاق عليها.</small>
            </div>
          </>
        ) : (
          <div className="empty-cart"><span>⌑</span><h3>سلتك فارغة</h3><p>أضف منتجات النادي ثم ارجع لإكمال طلبك.</p><button type="button" onClick={closeDrawer}>تصفّح المنتجات</button></div>
        )}
      </aside>
    </div>
  );
}
