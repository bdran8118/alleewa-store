import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "متجر نادي اللواء",
  description: "متجر منتجات نادي اللواء",
  icons: {
    icon: "/club-logo.jpeg",
    shortcut: "/club-logo.jpeg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl">
      <body>{children}</body>
    </html>
  );
}
