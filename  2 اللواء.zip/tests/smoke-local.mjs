import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";

const baseUrl = process.env.ALLEEWA_TEST_URL ?? "http://127.0.0.1:8788";
const setupCode = process.env.ALLEEWA_TEST_SETUP_CODE;
const password = process.env.ALLEEWA_TEST_PASSWORD;

assert.ok(setupCode, "ALLEEWA_TEST_SETUP_CODE is required");
assert.ok(password, "ALLEEWA_TEST_PASSWORD is required");

async function json(path, init = {}) {
  const response = await fetch(baseUrl + path, init);
  const data = await response.json();
  return { response, data };
}

function cookieFrom(response) {
  const setCookie = response.headers.get("set-cookie");
  assert.ok(setCookie, "Expected an admin session cookie");
  return setCookie.split(";", 1)[0];
}

const home = await fetch(baseUrl + "/");
assert.equal(home.status, 200);
assert.match(await home.text(), /متجر نادي اللواء/u);

const initialStatus = await json("/api/admin/status");
assert.equal(initialStatus.response.status, 200);

let authResponse;
if (initialStatus.data.canSetup) {
  authResponse = await json("/api/admin/setup", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      origin: baseUrl,
    },
    body: JSON.stringify({
      setupCode,
      displayName: "اختبار مدير المتجر",
      password,
    }),
  });
  assert.equal(authResponse.response.status, 201);
} else {
  authResponse = await json("/api/admin/login", {
    method: "POST",
    headers: {
      "content-type": "application/json",
      origin: baseUrl,
    },
    body: JSON.stringify({ password }),
  });
  assert.equal(authResponse.response.status, 200);
}

const cookie = cookieFrom(authResponse.response);
const adminHeaders = { cookie, origin: baseUrl };

const authenticatedStatus = await json("/api/admin/status", {
  headers: { cookie },
});
assert.equal(authenticatedStatus.data.isAdmin, true);

const form = new FormData();
form.set(
  "file",
  new Blob([await readFile(new URL("../public/club-logo.jpeg", import.meta.url))], {
    type: "image/jpeg",
  }),
  "club-logo.jpeg",
);
const upload = await json("/api/admin/upload", {
  method: "POST",
  headers: adminHeaders,
  body: form,
});
assert.equal(upload.response.status, 200);
assert.ok(upload.data.imageKey);

const productName = "منتج اختبار النقل " + Date.now();
const created = await json("/api/admin/products", {
  method: "POST",
  headers: {
    ...adminHeaders,
    "content-type": "application/json",
  },
  body: JSON.stringify({
    name: productName,
    description: "منتج مؤقت لاختبار وظائف المتجر",
    category: "اختبار",
    priceHalalas: 7500,
    stock: 3,
    isAvailable: true,
    isFeatured: true,
    imageKey: upload.data.imageKey,
    sizes: ["M", "L"],
  }),
});
assert.equal(created.response.status, 201);
const product = created.data.product;
assert.ok(product?.id);

const image = await fetch(baseUrl + product.imageUrl);
assert.equal(image.status, 200);
assert.match(image.headers.get("content-type") ?? "", /^image\/jpeg/u);

const publicProducts = await json("/api/products");
assert.ok(
  publicProducts.data.products.some((item) => item.id === product.id),
);

const order = await json("/api/orders", {
  method: "POST",
  headers: {
    "content-type": "application/json",
    origin: baseUrl,
  },
  body: JSON.stringify({
    customerName: "عميل الاختبار",
    phone: "0500000000",
    city: "بقعاء",
    notes: "طلب اختبار محلي",
    items: [{ productId: product.id, quantity: 1, selectedSize: "M" }],
  }),
});
assert.equal(order.response.status, 201);
assert.ok(order.data.orderId);

const adminOrders = await json("/api/admin/orders", {
  headers: { cookie },
});
assert.ok(
  adminOrders.data.orders.some((item) => item.id === order.data.orderId),
);

const orderUpdate = await json(
  "/api/admin/orders/" + encodeURIComponent(order.data.orderId),
  {
    method: "PATCH",
    headers: {
      ...adminHeaders,
      "content-type": "application/json",
    },
    body: JSON.stringify({ status: "processing" }),
  },
);
assert.equal(orderUpdate.data.success, true);

const deleted = await json("/api/admin/products/" + product.id, {
  method: "DELETE",
  headers: adminHeaders,
});
assert.equal(deleted.data.success, true);

console.log("SMOKE_OK storefront auth upload products orders inventory");
