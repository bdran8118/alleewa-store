import { desc } from "drizzle-orm";
import { getReadyDb } from "../db";
import { orders, products } from "../db/schema";
import type { ProductInput, StoreOrder, StoreProduct } from "./store-types";

function safeArray(value: string): string[] {
  try {
    const parsed = JSON.parse(value);
    return Array.isArray(parsed)
      ? parsed.filter((item): item is string => typeof item === "string")
      : [];
  } catch {
    return [];
  }
}

export function productToPublic(
  product: typeof products.$inferSelect,
): StoreProduct {
  return {
    ...product,
    imageUrl: product.imageKey
      ? `/api/images/${product.imageKey
          .split("/")
          .map(encodeURIComponent)
          .join("/")}`
      : null,
    sizes: safeArray(product.sizesJson),
  };
}

export async function listProducts(includeUnavailable = false) {
  const db = await getReadyDb();
  const rows = includeUnavailable
    ? await db.select().from(products).orderBy(desc(products.createdAt))
    : await db
        .select()
        .from(products)
        .orderBy(desc(products.isFeatured), desc(products.isAvailable), desc(products.createdAt));
  return rows.map(productToPublic);
}

export async function listOrders(): Promise<StoreOrder[]> {
  const rows = await (await getReadyDb())
    .select()
    .from(orders)
    .orderBy(desc(orders.createdAt));
  return rows.map((order) => ({
    ...order,
    items: JSON.parse(order.itemsJson),
  }));
}

export function normalizeProductInput(payload: Partial<ProductInput>) {
  const name = String(payload.name ?? "").trim();
  const description = String(payload.description ?? "").trim();
  const category = String(payload.category ?? "").trim() || "منتجات النادي";
  const priceHalalas = Number(payload.priceHalalas);
  const stock = Math.max(0, Math.floor(Number(payload.stock)));
  const sizes = Array.isArray(payload.sizes)
    ? payload.sizes.map(String).map((item) => item.trim()).filter(Boolean)
    : [];
  const imageKey = payload.imageKey ? String(payload.imageKey) : null;

  if (!name) throw new Error("اسم المنتج مطلوب");
  if (!Number.isInteger(priceHalalas) || priceHalalas < 0) {
    throw new Error("سعر المنتج غير صحيح");
  }
  if (!Number.isInteger(stock)) throw new Error("الكمية غير صحيحة");

  return {
    name,
    description,
    category,
    priceHalalas,
    stock,
    isAvailable: Boolean(payload.isAvailable),
    isFeatured: Boolean(payload.isFeatured),
    imageKey,
    sizesJson: JSON.stringify([...new Set(sizes)]),
  };
}
