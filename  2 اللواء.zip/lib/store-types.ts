export type StoreProduct = {
  id: number;
  name: string;
  description: string;
  category: string;
  priceHalalas: number;
  stock: number;
  isAvailable: boolean;
  isFeatured: boolean;
  imageKey: string | null;
  imageUrl: string | null;
  sizes: string[];
  createdAt: string;
  updatedAt: string;
};

export type CartItem = {
  product: StoreProduct;
  quantity: number;
  selectedSize: string;
};

export type OrderItem = {
  productId: number;
  name: string;
  priceHalalas: number;
  quantity: number;
  selectedSize: string;
};

export type StoreOrder = {
  id: string;
  customerName: string;
  phone: string;
  city: string;
  notes: string;
  items: OrderItem[];
  totalHalalas: number;
  status: string;
  createdAt: string;
  updatedAt: string;
};

export type ProductInput = {
  name: string;
  description: string;
  category: string;
  priceHalalas: number;
  stock: number;
  isAvailable: boolean;
  isFeatured: boolean;
  imageKey: string | null;
  sizes: string[];
};
