import { env } from "cloudflare:workers";

export function getStoreRuntimeEnv() {
  if (!env.DB || !env.IMAGES_KV) {
    throw new Error("Store persistence bindings are unavailable");
  }
  return env;
}
