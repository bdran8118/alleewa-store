#!/usr/bin/env bash
set -euo pipefail

test_log="$(mktemp /tmp/alleewa-smoke.XXXXXX.log)"
server_pid=""

cleanup() {
  if [[ -n "$server_pid" ]]; then
    kill "$server_pid" 2>/dev/null || true
    wait "$server_pid" 2>/dev/null || true
  fi
}
trap cleanup EXIT

npm run dev -- --hostname 127.0.0.1 --port 8788 >"$test_log" 2>&1 &
server_pid="$!"

ready=0
for _attempt in $(seq 1 80); do
  if curl --fail --silent --max-time 2 http://127.0.0.1:8788/ >/dev/null; then
    ready=1
    break
  fi
  if ! kill -0 "$server_pid" 2>/dev/null; then
    sed -n '1,220p' "$test_log" >&2
    exit 1
  fi
  sleep 0.25
done

if [[ "$ready" != "1" ]]; then
  sed -n '1,220p' "$test_log" >&2
  exit 1
fi

ALLEEWA_TEST_URL="http://127.0.0.1:8788" \
ALLEEWA_TEST_SETUP_CODE="TEST-ALLEEWA-2026" \
ALLEEWA_TEST_PASSWORD="Local-Test-Password-2026!" \
node tests/smoke-local.mjs
