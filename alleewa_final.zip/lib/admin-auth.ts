import { eq } from "drizzle-orm";
import { getReadyDb } from "../db";
import { adminLoginAttempts, admins } from "../db/schema";
import { getStoreRuntimeEnv } from "./runtime-env";

const ADMIN_USERNAME = "admin";
const SESSION_COOKIE = "alleewa_admin_session";
const SESSION_TTL_SECONDS = 8 * 60 * 60;
// Cloudflare Workers Web Crypto supports PBKDF2 iteration counts up to 100,000.
const PASSWORD_ITERATIONS = 100_000;
const LOGIN_WINDOW_SECONDS = 10 * 60;
const LOGIN_BLOCK_SECONDS = 15 * 60;
const MAX_LOGIN_ATTEMPTS = 5;
const encoder = new TextEncoder();

export type AdminUser = {
  username: string;
  displayName: string;
};

type SessionPayload = {
  version: 1;
  username: string;
  displayName: string;
  expiresAt: number;
};

export function validateAdminPassword(password: string): string | null {
  if (password.length < 10) return "كلمة المرور يجب أن تكون 10 أحرف على الأقل";
  if (password.length > 128) return "كلمة المرور طويلة جدًا";
  return null;
}

export async function createPasswordRecord(password: string) {
  const validationError = validateAdminPassword(password);
  if (validationError) throw new Error(validationError);

  const salt = crypto.getRandomValues(new Uint8Array(16));
  const hash = await derivePasswordHash(password, salt);
  return {
    passwordHash: bytesToBase64Url(hash),
    passwordSalt: bytesToBase64Url(salt),
  };
}

export async function verifyAdminPassword(
  password: string,
  passwordSalt: string,
  passwordHash: string,
) {
  if (password.length > 128) return false;
  try {
    const salt = base64UrlToBytes(passwordSalt);
    const expected = base64UrlToBytes(passwordHash);
    const actual = await derivePasswordHash(password, salt);
    return timingSafeEqual(actual, expected);
  } catch {
    return false;
  }
}

export async function matchesAdminSetupCode(candidate: string) {
  const { ADMIN_SETUP_CODE, SESSION_SECRET } = getAuthBindings();
  if (!candidate || !ADMIN_SETUP_CODE) return false;
  const key = await importHmacKey(SESSION_SECRET);
  const expected = await crypto.subtle.sign(
    "HMAC",
    key,
    encoder.encode(ADMIN_SETUP_CODE),
  );
  return crypto.subtle.verify(
    "HMAC",
    key,
    expected,
    encoder.encode(candidate),
  );
}

export async function createAdminSessionCookie(user: AdminUser) {
  const payload: SessionPayload = {
    version: 1,
    username: user.username,
    displayName: user.displayName,
    expiresAt: Math.floor(Date.now() / 1000) + SESSION_TTL_SECONDS,
  };
  const payloadPart = bytesToBase64Url(
    encoder.encode(JSON.stringify(payload)),
  );
  const signature = await signValue(payloadPart);
  const value = payloadPart + "." + bytesToBase64Url(signature);
  return serializeCookie(value, SESSION_TTL_SECONDS);
}

export function clearAdminSessionCookie() {
  return serializeCookie("", 0);
}

export async function getAdminState(request: Request) {
  const db = await getReadyDb();
  const [configuredAdmin] = await db.select().from(admins).limit(1);
  if (!configuredAdmin) {
    return {
      user: null,
      isAdmin: false,
      canSetup: true,
    };
  }

  const session = await readSession(request);
  if (!session) {
    return {
      user: null,
      isAdmin: false,
      canSetup: false,
    };
  }

  const [currentAdmin] = await db
    .select()
    .from(admins)
    .where(eq(admins.username, session.username))
    .limit(1);
  if (!currentAdmin) {
    return {
      user: null,
      isAdmin: false,
      canSetup: false,
    };
  }

  return {
    user: {
      username: currentAdmin.username,
      displayName: currentAdmin.displayName,
    },
    isAdmin: true,
    canSetup: false,
  };
}

export async function requireAdmin(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return { ok: false as const, response: crossOrigin };

  const state = await getAdminState(request);
  if (!state.isAdmin || !state.user) {
    return {
      ok: false as const,
      response: Response.json(
        { error: "انتهت الجلسة أو يلزم تسجيل الدخول" },
        { status: 401 },
      ),
    };
  }
  return { ok: true as const, user: state.user };
}

export function rejectCrossOrigin(request: Request): Response | null {
  if (request.method === "GET" || request.method === "HEAD") return null;
  const origin = request.headers.get("origin");
  if (origin) {
    try {
      if (new URL(origin).origin === new URL(request.url).origin) return null;
    } catch {
      // Fall through to the rejection below.
    }
  }
  return Response.json({ error: "الطلب غير مسموح" }, { status: 403 });
}

export async function getLoginRateLimit(request: Request) {
  const key = await loginAttemptKey(request);
  const now = Math.floor(Date.now() / 1000);
  const db = await getReadyDb();
  const [record] = await db
    .select()
    .from(adminLoginAttempts)
    .where(eq(adminLoginAttempts.key, key))
    .limit(1);

  if (!record) return { allowed: true as const, key };
  if (record.blockedUntil > now) {
    return {
      allowed: false as const,
      key,
      retryAfter: record.blockedUntil - now,
    };
  }
  if (now - record.windowStarted > LOGIN_WINDOW_SECONDS) {
    await db
      .delete(adminLoginAttempts)
      .where(eq(adminLoginAttempts.key, key));
  }
  return { allowed: true as const, key };
}

export async function recordLoginFailure(key: string) {
  const now = Math.floor(Date.now() / 1000);
  const db = await getReadyDb();
  const [record] = await db
    .select()
    .from(adminLoginAttempts)
    .where(eq(adminLoginAttempts.key, key))
    .limit(1);
  const activeWindow =
    record && now - record.windowStarted <= LOGIN_WINDOW_SECONDS;
  const attempts = activeWindow ? record.attempts + 1 : 1;
  const blockedUntil =
    attempts >= MAX_LOGIN_ATTEMPTS ? now + LOGIN_BLOCK_SECONDS : 0;
  const windowStarted = activeWindow ? record.windowStarted : now;

  await db
    .insert(adminLoginAttempts)
    .values({
      key,
      attempts,
      windowStarted,
      blockedUntil,
    })
    .onConflictDoUpdate({
      target: adminLoginAttempts.key,
      set: {
        attempts,
        windowStarted,
        blockedUntil,
      },
    });
}

export async function clearLoginFailures(key: string) {
  await (await getReadyDb())
    .delete(adminLoginAttempts)
    .where(eq(adminLoginAttempts.key, key));
}

export async function getConfiguredAdmin() {
  const [admin] = await (await getReadyDb()).select().from(admins).limit(1);
  return admin ?? null;
}

export function adminUsername() {
  return ADMIN_USERNAME;
}

async function readSession(request: Request): Promise<SessionPayload | null> {
  const rawCookie = readCookie(request.headers.get("cookie"), SESSION_COOKIE);
  if (!rawCookie) return null;

  const [payloadPart, signaturePart, extra] = rawCookie.split(".");
  if (!payloadPart || !signaturePart || extra) return null;
  try {
    const signature = base64UrlToBytes(signaturePart);
    const key = await importHmacKey(getAuthBindings().SESSION_SECRET);
    const valid = await crypto.subtle.verify(
      "HMAC",
      key,
      signature,
      encoder.encode(payloadPart),
    );
    if (!valid) return null;

    const payload = JSON.parse(
      new TextDecoder().decode(base64UrlToBytes(payloadPart)),
    ) as Partial<SessionPayload>;
    if (
      payload.version !== 1 ||
      payload.username !== ADMIN_USERNAME ||
      typeof payload.displayName !== "string" ||
      typeof payload.expiresAt !== "number" ||
      payload.expiresAt <= Math.floor(Date.now() / 1000)
    ) {
      return null;
    }
    return payload as SessionPayload;
  } catch {
    return null;
  }
}

async function derivePasswordHash(password: string, salt: Uint8Array) {
  const saltBuffer = Uint8Array.from(salt).buffer;
  const key = await crypto.subtle.importKey(
    "raw",
    encoder.encode(password),
    "PBKDF2",
    false,
    ["deriveBits"],
  );
  const bits = await crypto.subtle.deriveBits(
    {
      name: "PBKDF2",
      hash: "SHA-256",
      salt: saltBuffer,
      iterations: PASSWORD_ITERATIONS,
    },
    key,
    256,
  );
  return new Uint8Array(bits);
}

async function signValue(value: string) {
  const key = await importHmacKey(getAuthBindings().SESSION_SECRET);
  return new Uint8Array(
    await crypto.subtle.sign("HMAC", key, encoder.encode(value)),
  );
}

async function importHmacKey(secret: string) {
  if (!secret || secret.length < 32) {
    throw new Error("SESSION_SECRET is missing or too short");
  }
  return crypto.subtle.importKey(
    "raw",
    encoder.encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign", "verify"],
  );
}

async function loginAttemptKey(request: Request) {
  const forwardedIp =
    request.headers.get("cf-connecting-ip") ??
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    "unknown";
  return bytesToBase64Url(await signValue("admin-login:" + forwardedIp));
}

function getAuthBindings() {
  const bindings = getStoreRuntimeEnv();
  if (!bindings.ADMIN_SETUP_CODE) {
    throw new Error("ADMIN_SETUP_CODE is not configured");
  }
  if (!bindings.SESSION_SECRET) {
    throw new Error("SESSION_SECRET is not configured");
  }
  return bindings;
}

function serializeCookie(value: string, maxAge: number) {
  return [
    SESSION_COOKIE + "=" + encodeURIComponent(value),
    "Path=/",
    "HttpOnly",
    "Secure",
    "SameSite=Strict",
    "Max-Age=" + maxAge,
  ].join("; ");
}

function readCookie(header: string | null, name: string) {
  if (!header) return null;
  for (const part of header.split(";")) {
    const [key, ...valueParts] = part.trim().split("=");
    if (key !== name) continue;
    try {
      return decodeURIComponent(valueParts.join("="));
    } catch {
      return null;
    }
  }
  return null;
}

function bytesToBase64Url(bytes: Uint8Array) {
  let binary = "";
  for (const byte of bytes) binary += String.fromCharCode(byte);
  return btoa(binary)
    .replaceAll("+", "-")
    .replaceAll("/", "_")
    .replace(/=+$/u, "");
}

function base64UrlToBytes(value: string) {
  const normalized = value.replaceAll("-", "+").replaceAll("_", "/");
  const padding = "=".repeat((4 - (normalized.length % 4)) % 4);
  const binary = atob(normalized + padding);
  return Uint8Array.from(binary, (character) => character.charCodeAt(0));
}

function timingSafeEqual(left: Uint8Array, right: Uint8Array) {
  const length = Math.max(left.length, right.length);
  let difference = left.length ^ right.length;
  for (let index = 0; index < length; index += 1) {
    difference |=
      (left[index % Math.max(left.length, 1)] ?? 0) ^
      (right[index % Math.max(right.length, 1)] ?? 0);
  }
  return difference === 0;
}
