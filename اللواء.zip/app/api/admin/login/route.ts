import {
  clearLoginFailures,
  createAdminSessionCookie,
  getConfiguredAdmin,
  getLoginRateLimit,
  recordLoginFailure,
  rejectCrossOrigin,
  verifyAdminPassword,
} from "../../../../lib/admin-auth";

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  const rateLimit = await getLoginRateLimit(request);
  if (!rateLimit.allowed) {
    return Response.json(
      { error: "محاولات كثيرة. حاول بعد قليل" },
      {
        status: 429,
        headers: { "retry-after": String(rateLimit.retryAfter) },
      },
    );
  }

  try {
    const payload = (await request.json()) as { password?: string };
    const password = String(payload.password ?? "");
    const admin = await getConfiguredAdmin();
    const valid =
      admin &&
      (await verifyAdminPassword(
        password,
        admin.passwordSalt,
        admin.passwordHash,
      ));

    if (!admin || !valid) {
      await recordLoginFailure(rateLimit.key);
      return Response.json(
        { error: "كلمة المرور غير صحيحة" },
        { status: 401 },
      );
    }

    await clearLoginFailures(rateLimit.key);
    const user = {
      username: admin.username,
      displayName: admin.displayName,
    };
    return Response.json(
      { success: true, user },
      { headers: { "set-cookie": await createAdminSessionCookie(user) } },
    );
  } catch {
    return Response.json(
      { error: "تعذر تسجيل الدخول" },
      { status: 400 },
    );
  }
}
