import { getReadyDb } from "../../../../db";
import { admins } from "../../../../db/schema";
import {
  adminUsername,
  clearLoginFailures,
  createAdminSessionCookie,
  createPasswordRecord,
  getConfiguredAdmin,
  getLoginRateLimit,
  matchesAdminSetupCode,
  recordLoginFailure,
  rejectCrossOrigin,
} from "../../../../lib/admin-auth";

export async function POST(request: Request) {
  const crossOrigin = rejectCrossOrigin(request);
  if (crossOrigin) return crossOrigin;

  const rateLimit = await getLoginRateLimit(request);
  if (!rateLimit.allowed) {
    return Response.json(
      { error: "محاولات كثيرة. حاول بعد قليل" },
      {
        status: 429,
        headers: { "retry-after": String(rateLimit.retryAfter) },
      },
    );
  }

  try {
    if (await getConfiguredAdmin()) {
      return Response.json(
        { error: "تم إعداد مدير المتجر مسبقًا" },
        { status: 409 },
      );
    }

    const payload = (await request.json()) as {
      setupCode?: string;
      displayName?: string;
      password?: string;
    };
    const setupCode = String(payload.setupCode ?? "").trim();
    if (!(await matchesAdminSetupCode(setupCode))) {
      await recordLoginFailure(rateLimit.key);
      return Response.json(
        { error: "رمز التفعيل غير صحيح" },
        { status: 401 },
      );
    }

    const displayName =
      String(payload.displayName ?? "").trim().slice(0, 60) || "مدير المتجر";
    const password = String(payload.password ?? "");
    const passwordRecord = await createPasswordRecord(password);
    const user = { username: adminUsername(), displayName };

    await (await getReadyDb()).insert(admins).values({
      ...user,
      ...passwordRecord,
    });
    await clearLoginFailures(rateLimit.key);

    return Response.json(
      { success: true, user },
      {
        status: 201,
        headers: { "set-cookie": await createAdminSessionCookie(user) },
      },
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "تعذر إعداد حساب الإدارة";
    const status = message.includes("UNIQUE") ? 409 : 400;
    return Response.json({ error: message }, { status });
  }
}
