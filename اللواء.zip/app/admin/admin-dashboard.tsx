"use client";

import Link from "next/link";
import { useCallback, useEffect, useState } from "react";
import type { ProductInput, StoreOrder, StoreProduct } from "../../lib/store-types";

const money = new Intl.NumberFormat("ar-SA", {
  style: "currency",
  currency: "SAR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 2,
});

const orderStatuses: Record<string, string> = {
  new: "جديد",
  processing: "قيد التجهيز",
  ready: "جاهز",
  completed: "مكتمل",
  cancelled: "ملغي",
};

type AdminStatus = {
  signedIn: boolean;
  isAdmin: boolean;
  canSetup: boolean;
  user: { username: string; displayName: string } | null;
};

const blankForm: ProductInput = {
  name: "",
  description: "",
  category: "منتجات النادي",
  priceHalalas: 0,
  stock: 0,
  isAvailable: true,
  isFeatured: false,
  imageKey: null,
  sizes: [],
};

export default function AdminDashboard() {
  const [status, setStatus] = useState<AdminStatus | null>(null);
  const [products, setProducts] = useState<StoreProduct[]>([]);
  const [orders, setOrders] = useState<StoreOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [authSubmitting, setAuthSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [tab, setTab] = useState<"products" | "orders">("products");
  const [search, setSearch] = useState("");
  const [editorOpen, setEditorOpen] = useState(false);
  const [editing, setEditing] = useState<StoreProduct | null>(null);
  const [toast, setToast] = useState("");

  const loadData = useCallback(async () => {
    const [productsResponse, ordersResponse] = await Promise.all([
      fetch("/api/admin/products", { cache: "no-store" }),
      fetch("/api/admin/orders", { cache: "no-store" }),
    ]);
    const productsData = (await productsResponse.json()) as { products?: StoreProduct[]; error?: string };
    const ordersData = (await ordersResponse.json()) as { orders?: StoreOrder[]; error?: string };
    if (!productsResponse.ok) throw new Error(productsData.error || "تعذر تحميل المنتجات");
    if (!ordersResponse.ok) throw new Error(ordersData.error || "تعذر تحميل الطلبات");
    setProducts(productsData.products ?? []);
    setOrders(ordersData.orders ?? []);
  }, []);

  const loadStatus = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/admin/status", { cache: "no-store" });
      const data = (await response.json()) as AdminStatus & { error?: string };
      if (!response.ok) throw new Error(data.error || "تعذر تحميل لوحة الإدارة");
      setStatus(data);
      if (data.isAdmin) await loadData();
    } catch (loadError) {
      setError(loadError instanceof Error ? loadError.message : "تعذر تحميل لوحة الإدارة");
    } finally {
      setLoading(false);
    }
  }, [loadData]);

  useEffect(() => {
    const timer = window.setTimeout(() => void loadStatus(), 0);
    return () => window.clearTimeout(timer);
  }, [loadStatus]);

  useEffect(() => {
    if (!toast) return;
    const timer = window.setTimeout(() => setToast(""), 2500);
    return () => window.clearTimeout(timer);
  }, [toast]);

  async function setupAdmin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    const password = String(form.get("password") ?? "");
    const passwordConfirmation = String(
      form.get("passwordConfirmation") ?? "",
    );
    if (password !== passwordConfirmation) {
      setError("تأكيد كلمة المرور غير مطابق");
      return;
    }

    setAuthSubmitting(true);
    setError("");
    try {
      const response = await fetch("/api/admin/setup", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          setupCode: form.get("setupCode"),
          displayName: form.get("displayName"),
          password,
        }),
      });
      const data = (await response.json()) as { success?: boolean; error?: string };
      if (!response.ok || !data.success) {
        throw new Error(data.error || "تعذر تفعيل الإدارة");
      }
      await loadStatus();
      setToast("تم إعداد حساب مدير المتجر");
    } catch (setupError) {
      setError(
        setupError instanceof Error
          ? setupError.message
          : "تعذر تفعيل الإدارة",
      );
    } finally {
      setAuthSubmitting(false);
    }
  }

  async function loginAdmin(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = new FormData(event.currentTarget);
    setAuthSubmitting(true);
    setError("");
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password: form.get("password") }),
      });
      const data = (await response.json()) as {
        success?: boolean;
        error?: string;
      };
      if (!response.ok || !data.success) {
        throw new Error(data.error || "تعذر تسجيل الدخول");
      }
      await loadStatus();
    } catch (loginError) {
      setError(
        loginError instanceof Error
          ? loginError.message
          : "تعذر تسجيل الدخول",
      );
    } finally {
      setAuthSubmitting(false);
    }
  }

  async function logoutAdmin() {
    setError("");
    try {
      await fetch("/api/admin/logout", {
        method: "POST",
        redirect: "follow",
      });
    } finally {
      window.location.assign("/admin");
    }
  }

  function openNewProduct() {
    setEditing(null);
    setEditorOpen(true);
  }

  function openEdit(product: StoreProduct) {
    setEditing(product);
    setEditorOpen(true);
  }

  async function quickToggle(product: StoreProduct) {
    try {
      const response = await fetch(`/api/admin/products/${product.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ isAvailable: !product.isAvailable }),
      });
      const data = (await response.json()) as { product?: StoreProduct; error?: string };
      if (!response.ok || !data.product) throw new Error(data.error || "تعذر تحديث المنتج");
      setProducts((current) => current.map((item) => item.id === product.id ? data.product! : item));
      setToast(data.product.isAvailable ? "أصبح المنتج متوفرًا" : "تم وضع المنتج كغير متوفر");
    } catch (toggleError) {
      setError(toggleError instanceof Error ? toggleError.message : "تعذر تحديث المنتج");
    }
  }

  async function deleteProduct(product: StoreProduct) {
    if (!window.confirm(`حذف المنتج «${product.name}» نهائيًا؟`)) return;
    try {
      const response = await fetch(`/api/admin/products/${product.id}`, { method: "DELETE" });
      const data = (await response.json()) as { success?: boolean; error?: string };
      if (!response.ok || !data.success) throw new Error(data.error || "تعذر حذف المنتج");
      setProducts((current) => current.filter((item) => item.id !== product.id));
      setToast("تم حذف المنتج");
    } catch (deleteError) {
      setError(deleteError instanceof Error ? deleteError.message : "تعذر حذف المنتج");
    }
  }

  async function updateOrderStatus(orderId: string, nextStatus: string) {
    try {
      const response = await fetch(`/api/admin/orders/${encodeURIComponent(orderId)}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ status: nextStatus }),
      });
      const data = (await response.json()) as { success?: boolean; error?: string };
      if (!response.ok || !data.success) throw new Error(data.error || "تعذر تحديث الطلب");
      setOrders((current) => current.map((order) => order.id === orderId ? { ...order, status: nextStatus } : order));
      setToast("تم تحديث حالة الطلب");
    } catch (updateError) {
      setError(updateError instanceof Error ? updateError.message : "تعذر تحديث الطلب");
    }
  }

  if (loading) {
    return <AdminLoading />;
  }

  if (!status || error && !status) {
    return (
      <AdminMessage title="تعذر فتح لوحة الإدارة" text={error || "حدث خطأ غير متوقع"}>
        <button type="button" onClick={() => void loadStatus()}>إعادة المحاولة</button>
      </AdminMessage>
    );
  }

  if (!status.isAdmin && status.canSetup) {
    return (
      <AdminMessage
        title="إعداد حساب مدير المتجر"
        text="أدخل رمز التفعيل الذي سُلّم لك، ثم اختر كلمة مرور خاصة بك. هذه الخطوة تتم مرة واحدة فقط."
      >
        <form className="admin-auth-form" onSubmit={setupAdmin}>
          <label>
            <span>رمز التفعيل *</span>
            <input
              name="setupCode"
              required
              autoComplete="one-time-code"
              dir="ltr"
              placeholder="رمز التفعيل"
            />
          </label>
          <label>
            <span>اسم المدير</span>
            <input
              name="displayName"
              autoComplete="name"
              defaultValue="مدير المتجر"
              maxLength={60}
            />
          </label>
          <label>
            <span>كلمة المرور الجديدة *</span>
            <input
              name="password"
              required
              type="password"
              minLength={10}
              maxLength={128}
              autoComplete="new-password"
            />
            <small>10 أحرف على الأقل</small>
          </label>
          <label>
            <span>تأكيد كلمة المرور *</span>
            <input
              name="passwordConfirmation"
              required
              type="password"
              minLength={10}
              maxLength={128}
              autoComplete="new-password"
            />
          </label>
          {error && <p className="admin-error">{error}</p>}
          <button className="claim-button" type="submit" disabled={authSubmitting}>
            {authSubmitting ? "جاري الإعداد..." : "تفعيل لوحة الإدارة"}
          </button>
        </form>
        <Link className="outline-link" href="/">العودة للمتجر</Link>
      </AdminMessage>
    );
  }

  if (!status.isAdmin) {
    return (
      <AdminMessage
        title="تسجيل دخول الإدارة"
        text="أدخل كلمة المرور لإدارة المنتجات والكميات والأسعار والطلبات."
      >
        <form className="admin-auth-form compact" onSubmit={loginAdmin}>
          <label>
            <span>كلمة المرور *</span>
            <input
              name="password"
              required
              type="password"
              maxLength={128}
              autoComplete="current-password"
              autoFocus
            />
          </label>
          {error && <p className="admin-error">{error}</p>}
          <button className="claim-button" type="submit" disabled={authSubmitting}>
            {authSubmitting ? "جاري الدخول..." : "تسجيل الدخول"}
          </button>
        </form>
        <Link className="outline-link" href="/">العودة للمتجر</Link>
      </AdminMessage>
    );
  }

  if (!status.user) {
    return (
      <AdminMessage title="تعذر فتح لوحة الإدارة" text="لم يتم العثور على بيانات المدير.">
        {error && <p className="admin-error">{error}</p>}
        <Link className="outline-link" href="/">العودة للمتجر</Link>
      </AdminMessage>
    );
  }

  const user = status.user;

  const filteredProducts = products.filter((product) =>
    !search.trim() || product.name.includes(search.trim()) || product.category.includes(search.trim()),
  );
  const newOrders = orders.filter((order) => order.status === "new").length;
  const availableProducts = products.filter((product) => product.isAvailable && product.stock > 0).length;
  const lowStock = products.filter((product) => product.isAvailable && product.stock > 0 && product.stock <= 5).length;

  return (
    <main className="admin-shell">
      <aside className="admin-sidebar">
        <a className="admin-brand" href="/admin">
          <img src="/club-logo.jpeg" alt="شعار نادي اللواء" />
          <span><strong>إدارة المتجر</strong><small>AL LEEWA STORE</small></span>
        </a>
        <nav>
          <button className={tab === "products" ? "active" : ""} type="button" onClick={() => setTab("products")}><span>▦</span> المنتجات</button>
          <button className={tab === "orders" ? "active" : ""} type="button" onClick={() => setTab("orders")}><span>▤</span> الطلبات {newOrders > 0 && <b>{newOrders}</b>}</button>
        </nav>
        <div className="sidebar-bottom">
          <a href="/" target="_blank"><span>↗</span> عرض المتجر</a>
          <button type="button" onClick={() => void logoutAdmin()}><span>↪</span> تسجيل الخروج</button>
        </div>
      </aside>

      <section className="admin-main">
        <header className="admin-topbar">
          <div>
            <span>لوحة التحكم</span>
            <h1>{tab === "products" ? "إدارة المنتجات" : "طلبات المتجر"}</h1>
          </div>
          <div className="admin-user"><span>{user.displayName.slice(0, 1)}</span><p><strong>{user.displayName}</strong><small>مدير المتجر</small></p></div>
        </header>

        <div className="stats-grid">
          <article><span className="stat-icon blue">▦</span><p><small>إجمالي المنتجات</small><strong>{products.length}</strong></p></article>
          <article><span className="stat-icon green">✓</span><p><small>منتجات متوفرة</small><strong>{availableProducts}</strong></p></article>
          <article><span className="stat-icon yellow">!</span><p><small>مخزون منخفض</small><strong>{lowStock}</strong></p></article>
          <article><span className="stat-icon purple">▤</span><p><small>طلبات جديدة</small><strong>{newOrders}</strong></p></article>
        </div>

        {error && <div className="admin-alert"><span>{error}</span><button type="button" onClick={() => setError("")}>×</button></div>}

        {tab === "products" ? (
          <section className="admin-panel">
            <div className="panel-heading">
              <div><h2>قائمة المنتجات</h2><p>أضف وعدّل السعر والكمية والصورة وحالة التوفر.</p></div>
              <div className="panel-actions">
                <label className="admin-search"><span>⌕</span><input value={search} onChange={(event) => setSearch(event.target.value)} placeholder="بحث بالاسم أو التصنيف" /></label>
                <button className="new-product-button" type="button" onClick={openNewProduct}>+ إضافة منتج</button>
              </div>
            </div>
            <ProductsTable products={filteredProducts} onEdit={openEdit} onToggle={quickToggle} onDelete={deleteProduct} />
          </section>
        ) : (
          <section className="admin-panel">
            <div className="panel-heading"><div><h2>طلبات العملاء</h2><p>راجع تفاصيل الطلب وغيّر حالته حسب التجهيز.</p></div></div>
            <OrdersList orders={orders} onStatusChange={updateOrderStatus} />
          </section>
        )}
      </section>

      {editorOpen && (
        <ProductEditor
          product={editing}
          onClose={() => setEditorOpen(false)}
          onSaved={(product) => {
            setProducts((current) => {
              const exists = current.some((item) => item.id === product.id);
              return exists ? current.map((item) => item.id === product.id ? product : item) : [product, ...current];
            });
            setEditorOpen(false);
            setToast(editing ? "تم حفظ التعديلات" : "تمت إضافة المنتج");
          }}
        />
      )}

      {toast && <div className="admin-toast">✓ {toast}</div>}
    </main>
  );
}

function ProductsTable({
  products,
  onEdit,
  onToggle,
  onDelete,
}: {
  products: StoreProduct[];
  onEdit: (product: StoreProduct) => void;
  onToggle: (product: StoreProduct) => void;
  onDelete: (product: StoreProduct) => void;
}) {
  if (!products.length) {
    return <div className="admin-empty"><span>▦</span><h3>لا توجد منتجات</h3><p>ابدأ بإضافة أول منتج إلى متجر نادي اللواء.</p></div>;
  }
  return (
    <div className="products-table-wrap">
      <table className="products-table">
        <thead><tr><th>المنتج</th><th>السعر</th><th>المخزون</th><th>الحالة</th><th>الإجراءات</th></tr></thead>
        <tbody>
          {products.map((product) => (
            <tr key={product.id}>
              <td><div className="table-product"><span>{product.imageUrl ? <img src={product.imageUrl} alt="" /> : <img src="/club-logo.jpeg" alt="" />}</span><p><strong>{product.name}</strong><small>{product.category}{product.isFeatured ? " · منتج مختار" : ""}</small></p></div></td>
              <td><strong className="table-price">{money.format(product.priceHalalas / 100)}</strong></td>
              <td><span className={product.stock <= 5 ? "stock-low" : ""}>{product.stock}</span></td>
              <td><button className={`availability ${product.isAvailable && product.stock > 0 ? "available" : "offline"}`} type="button" onClick={() => void onToggle(product)}><i />{product.isAvailable && product.stock > 0 ? "متوفر" : "غير متوفر"}</button></td>
              <td><div className="row-actions"><button type="button" onClick={() => onEdit(product)}>تعديل</button><button className="delete" type="button" onClick={() => void onDelete(product)}>حذف</button></div></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OrdersList({ orders, onStatusChange }: { orders: StoreOrder[]; onStatusChange: (id: string, status: string) => void }) {
  if (!orders.length) return <div className="admin-empty"><span>▤</span><h3>لا توجد طلبات بعد</h3><p>ستظهر طلبات العملاء هنا فور إرسالها من المتجر.</p></div>;
  return (
    <div className="orders-list">
      {orders.map((order) => (
        <article className="order-card" key={order.id}>
          <div className="order-head">
            <div><small>رقم الطلب</small><strong dir="ltr">{order.id}</strong></div>
            <div><small>التاريخ</small><strong>{new Date(order.createdAt + "Z").toLocaleString("ar-SA", { dateStyle: "medium", timeStyle: "short" })}</strong></div>
            <select value={order.status} onChange={(event) => void onStatusChange(order.id, event.target.value)} aria-label="حالة الطلب">
              {Object.entries(orderStatuses).map(([value, label]) => <option value={value} key={value}>{label}</option>)}
            </select>
          </div>
          <div className="order-body">
            <div className="customer-details"><h3>{order.customerName}</h3><a href={`tel:${order.phone}`} dir="ltr">{order.phone}</a>{order.city && <span>{order.city}</span>}{order.notes && <p>{order.notes}</p>}</div>
            <div className="order-products">
              {order.items.map((item, index) => <div key={`${order.id}-${index}`}><span>{item.name}{item.selectedSize ? ` · ${item.selectedSize}` : ""}</span><b>{item.quantity} × {money.format(item.priceHalalas / 100)}</b></div>)}
            </div>
            <div className="order-total"><small>الإجمالي</small><strong>{money.format(order.totalHalalas / 100)}</strong></div>
          </div>
        </article>
      ))}
    </div>
  );
}

function ProductEditor({ product, onClose, onSaved }: { product: StoreProduct | null; onClose: () => void; onSaved: (product: StoreProduct) => void }) {
  const [form, setForm] = useState<ProductInput>(() => product ? {
    name: product.name,
    description: product.description,
    category: product.category,
    priceHalalas: product.priceHalalas,
    stock: product.stock,
    isAvailable: product.isAvailable,
    isFeatured: product.isFeatured,
    imageKey: product.imageKey,
    sizes: product.sizes,
  } : blankForm);
  const [price, setPrice] = useState(product ? String(product.priceHalalas / 100) : "");
  const [sizes, setSizes] = useState(product?.sizes.join(", ") ?? "");
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState(product?.imageUrl ?? "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    return () => {
      if (preview.startsWith("blob:")) URL.revokeObjectURL(preview);
    };
  }, [preview]);

  function pickFile(event: React.ChangeEvent<HTMLInputElement>) {
    const nextFile = event.target.files?.[0] ?? null;
    if (!nextFile) return;
    if (preview.startsWith("blob:")) URL.revokeObjectURL(preview);
    setFile(nextFile);
    setPreview(URL.createObjectURL(nextFile));
  }

  async function save(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setSaving(true);
    setError("");
    try {
      let imageKey = form.imageKey;
      if (file) {
        const body = new FormData();
        body.set("file", file);
        const uploadResponse = await fetch("/api/admin/upload", { method: "POST", body });
        const uploadData = (await uploadResponse.json()) as { imageKey?: string; error?: string };
        if (!uploadResponse.ok || !uploadData.imageKey) throw new Error(uploadData.error || "تعذر رفع الصورة");
        imageKey = uploadData.imageKey;
      }

      const payload: ProductInput = {
        ...form,
        priceHalalas: Math.round(Number(price) * 100),
        stock: Math.max(0, Math.floor(Number(form.stock))),
        imageKey,
        sizes: sizes.split(",").map((item) => item.trim()).filter(Boolean),
      };
      const response = await fetch(product ? `/api/admin/products/${product.id}` : "/api/admin/products", {
        method: product ? "PATCH" : "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { product?: StoreProduct; error?: string };
      if (!response.ok || !data.product) throw new Error(data.error || "تعذر حفظ المنتج");
      onSaved(data.product);
    } catch (saveError) {
      setError(saveError instanceof Error ? saveError.message : "تعذر حفظ المنتج");
    } finally {
      setSaving(false);
    }
  }

  return (
    <div className="editor-layer" role="dialog" aria-modal="true" aria-label={product ? "تعديل المنتج" : "إضافة منتج"}>
      <button className="editor-backdrop" type="button" onClick={onClose} aria-label="إغلاق" />
      <form className="product-editor" onSubmit={save}>
        <header><div><span>{product ? "تعديل المنتج" : "منتج جديد"}</span><small>أدخل معلومات المنتج كما ستظهر للعملاء</small></div><button type="button" onClick={onClose}>×</button></header>
        <div className="editor-content">
          <label className="image-upload">
            {preview ? <img src={preview} alt="معاينة صورة المنتج" /> : <span><b>＋</b><strong>ارفع صورة المنتج</strong><small>JPG أو PNG أو WEBP — حتى 8MB</small></span>}
            <input type="file" accept="image/jpeg,image/png,image/webp,image/avif" onChange={pickFile} />
            {preview && <i>تغيير الصورة</i>}
          </label>
          <div className="editor-fields">
            <label className="wide"><span>اسم المنتج *</span><input required value={form.name} onChange={(event) => setForm({ ...form, name: event.target.value })} placeholder="مثال: قميص نادي اللواء" /></label>
            <label><span>التصنيف *</span><input required value={form.category} onChange={(event) => setForm({ ...form, category: event.target.value })} placeholder="الملابس" /></label>
            <label><span>السعر بالريال *</span><input required min="0" step="0.01" type="number" inputMode="decimal" dir="ltr" value={price} onChange={(event) => setPrice(event.target.value)} placeholder="0.00" /></label>
            <label><span>الكمية المتوفرة *</span><input required min="0" step="1" type="number" inputMode="numeric" dir="ltr" value={form.stock} onChange={(event) => setForm({ ...form, stock: Number(event.target.value) })} /></label>
            <label><span>المقاسات</span><input dir="ltr" value={sizes} onChange={(event) => setSizes(event.target.value)} placeholder="S, M, L, XL" /><small>افصل بين المقاسات بفاصلة</small></label>
            <label className="wide"><span>وصف المنتج</span><textarea rows={4} value={form.description} onChange={(event) => setForm({ ...form, description: event.target.value })} placeholder="الخامة، التفاصيل، وما يميز المنتج" /></label>
            <div className="wide editor-switches">
              <label><input type="checkbox" checked={form.isAvailable} onChange={(event) => setForm({ ...form, isAvailable: event.target.checked })} /><span><b>متوفر للبيع</b><small>ألغِ الاختيار لإظهار «غير متوفر»</small></span></label>
              <label><input type="checkbox" checked={form.isFeatured} onChange={(event) => setForm({ ...form, isFeatured: event.target.checked })} /><span><b>منتج مختار</b><small>يظهر أولًا في واجهة المتجر</small></span></label>
            </div>
          </div>
        </div>
        {error && <p className="editor-error">{error}</p>}
        <footer><button className="cancel-edit" type="button" onClick={onClose}>إلغاء</button><button className="save-product" disabled={saving} type="submit">{saving ? "جاري الحفظ..." : product ? "حفظ التعديلات" : "إضافة المنتج"}</button></footer>
      </form>
    </div>
  );
}

function AdminLoading() {
  return <main className="admin-loading"><img src="/club-logo.jpeg" alt="شعار نادي اللواء" /><span /><p>جاري تجهيز لوحة الإدارة...</p></main>;
}

function AdminMessage({ title, text, children }: { title: string; text: string; children: React.ReactNode }) {
  return <main className="admin-gate"><section><img src="/club-logo.jpeg" alt="شعار نادي اللواء" /><span className="gate-kicker">متجر نادي اللواء</span><h1>{title}</h1><p>{text}</p>{children}</section></main>;
}
